/**
 * Jonathan Yeh
 * MonetaryCoin
 * 
 * It extends the Coin class and has a value. 
 */

public class MonetaryCoin extends Coin
{
    private double value;
    
    public MonetaryCoin(double v)
    {
        super();
        value = v;
    }
    //returns value of the monetary coin
    public double getValue()
    {
        return value;
    }
}
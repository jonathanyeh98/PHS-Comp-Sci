import java.util.ArrayList;
import java.text.NumberFormat;
/**
 * Jonathan Yeh
 * MonetaryCoinDriver
 * 
 * Driver to test the MonetaryCoin object and the things it inheirits from Coin
 */

public class MonetaryCoinDriver
{
    public static void main(String[] args)
    {
        NumberFormat n = NumberFormat.getCurrencyInstance();
        ArrayList<MonetaryCoin> m = new ArrayList<MonetaryCoin>();
        m.add(new MonetaryCoin(0.01));
        m.add(new MonetaryCoin(0.05));
        m.add(new MonetaryCoin(0.10));
        m.add(new MonetaryCoin(0.25));
        
        System.out.println("There are four coins: a penny, a nickel, a dime, and a quarter");
        String s = "Their respective values are: ";
        double v = 0.0;
        String f = "Their respective face orientations are: ";
        for(int i = 0 ; i < m.size() ; i++)
        {
            m.get(i).flip(); //MonetaryCoin inheirits the flip methods
            s += n.format(m.get(i).getValue()) + "/ ";
            v += m.get(i).getValue();
            f += m.get(i).toString() + "/ "; //MonetaryCoin inheirits the toString methods
        }
        System.out.println(s);
        System.out.println("Their total value is " + n.format(v));
        System.out.println(f);
    }
}
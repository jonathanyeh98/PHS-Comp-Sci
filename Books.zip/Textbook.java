/**
 * Jonathan Yeh
 * Textbook
 * 
 * <Description>
 */

public class Textbook extends RefBook
{
    public String topic;
    
    public Textbook(String t , String a , int p , int y, String to)
    {
        super(t , a , p , y , "Textbook" + "(" + to + ")");
        topic = to;
    }
    
    public String getTopic()
    {
        return topic;
    }
    
}
/**
 * Jonathan Yeh
 * NonFic
 * 
 * <Description>
 */

public class NonFic extends Novel
{
    public NonFic(String t , String a , int p , int y)
    {
        super(t , a , p , y);
    }
    
    public String toString()
    {
        return author + ", " + title + "(" + pubYear + "): " + genre + "(Non-Fic)" + " ; Pages: " + pages;
    }
}
/**
 * Jonathan Yeh
 * Book
 * 
 * Allows the creation of the Book object. It contains a integer number of pages, book genre, and title
 */

public class Book
{
    public int pages;
    public String author;
    public String genre;
    public String title;
    public int pubYear;
    
    public Book (String t , String a , String g , int p , int y)
    {
        pages = p;
        genre = g;
        title = t;
        pubYear = y;
        author = a;
    }
}
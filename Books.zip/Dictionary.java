/**
 * Jonathan Yeh
 * Dictionary
 * 
 * <Description>
 */

public class Dictionary extends RefBook
{
    public int definitions;
    
    public Dictionary(String t , String a , int p , int y, int d)
    {
        super(t , a , p , y , "Dictionary");
        definitions = d;
    }
    
    public int getDefinitions()
    {
        return definitions;
    }
}
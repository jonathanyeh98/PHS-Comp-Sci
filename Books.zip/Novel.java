/**
 * Jonathan Yeh
 * Novel
 * 
 * <Description>
 */

public class Novel extends Book
{
    public String plot;
    
    public Novel(String t , String a , int p , int y)
    {
        super(t , a , "Novel" , p , y);
    }
    
    public void addPlot(String s)
    {
        plot = s;
    }
    
    public String getPlot()
    {
        return plot;
    }
}
/**
 * Jonathan Yeh
 * RefBook
 * 
 * <Description>
 */

public class RefBook extends Book
{
    public String type;
    
    public RefBook(String t , String a , int p , int y, String ty)
    {
        super(t , a , "Reference" , p , y);
        type = ty;
    }
    
    public String toString()
    {
        return author + ", " + title + "(" + pubYear + "): " + genre + " ; Pages: " + pages + " ; Type: " + type;
    }
}
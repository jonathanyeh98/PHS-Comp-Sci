/**
 * Jonathan Yeh
 * BookDriver
 * 
 * <Description>
 */

public class BookDriver
{
    public static void main(String[] args)
    {
        Dictionary websters = new Dictionary ("Webster's Dictionary", "Web Webster" , 400 , 2005 , 15000);
        Dictionary oxford = new Dictionary ("Oxford's Dictionary", "Ox Oxford" , 550 , 2012 , 15010);
        System.out.println(websters + "\nDefinitions : " + websters.getDefinitions());
        System.out.println(oxford + "\nDefinitions : " + oxford.getDefinitions() + "\n");
        
        Textbook calculusForAP = new Textbook ("Calculus for AP", "Mathy McMathy", 500 , 2010 , "Math");
        Textbook historyForIB = new Textbook ("History for IB", "Histy O'Histy", 450 , 2007 , "History");
        System.out.println(calculusForAP + "\n" + historyForIB + "\n");
        
        Fiction catcher = new Fiction ("Catcher in the Rye", "JD Salinger", 250, 1951);
        catcher.addPlot("Kid walks around New York");
        Fiction funnyBook = new Fiction ("Funny Book", "Fun Funnerson", 155, 2017);
        funnyBook.addPlot("Someone does something funny");
        System.out.println(catcher + "\nSummary: " + catcher.getPlot());
        System.out.println(funnyBook + "\nSummary: " + funnyBook.getPlot() + "\n");
        
        NonFic economicsBook = new NonFic ("Economics of People", "Eco Nomics", 570, 2016);
        economicsBook.addPlot("Brief history of economics");
        NonFic walkInWoods = new NonFic ("A Walk in the Woods", "Bill Bryson", 640, 1998);
        walkInWoods.addPlot("Bill Bryson walks in the woods");
        System.out.println(economicsBook + "\nSummary: " + economicsBook.getPlot());
        System.out.println(walkInWoods + "\nSummary: " + walkInWoods.getPlot() + "\n");
    }
}
/**
 * Jonathan Yeh
 * Fiction
 * 
 * <Description>
 */

public class Fiction extends Novel
{
    public Fiction(String t , String a , int p , int y)
    {
        super(t , a , p , y);
    }
    
    public String toString()
    {
        return author + ", " + title + "(" + pubYear + "): " + genre + "(Fic)" + " ; Pages: " + pages;
    }
}

/**
 * Represents a turtle
 * 
 * @Lchen
 * @1/13/17
 */
public class Turtle extends Animal
{
    public Turtle(double a, String b)
    {
        super(a,b);
    }
    
    public String haveShell()
    {
        return "I have a shell";
    }
}


/**
 * Jonathan Yeh
 * Aligator
 * 
 * <Description>
 */

public class Aligator extends Animal
{
    public Aligator(double p , String n)
    {
        super(p,n);
    }
    
    public String chomp()
    {
        return "I chomp on stuff.";
    }
}
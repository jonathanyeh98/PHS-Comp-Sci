/**
 * Jonathan Yeh
 * Animal
 * 
 * <Description>
 */

public class Animal
{
    private double price;
    private String phrase;
    
    public Animal(double p, String n)
    {
        price = p;
        phrase = n;
    }
    
    public String whatIAm()
    {
        return phrase;
    }
    
    public double getPrice()
    {
        return price;
    }
    
    public String whatICanDo()
    {
        return "I do stuff";
    }
}
import java.util.ArrayList;
/**
 * Jonathan Yeh
 * PetSet
 * 
 * <Description>
 */

public class PetSet
{
    private double maxPrice;
    private ArrayList<Animal> s;
    private double sum;
    public PetSet()
    {
        s = new ArrayList<Animal>();
        maxPrice = 0.00;
        sum = 0.00;
    }
    
    public void add(Animal a)
    {
        s.add(a);
        sum += a.getPrice();
        if(a.getPrice() < maxPrice)
        {
            maxPrice = a.getPrice();
        }
    }
    
    public String toString()
    {
        String str = "";
        for(int i = 0 ; i < s.size() ; i++)
        {
            str += s.get(i).whatIAm() + "\n";
        }
        return str;
    }
    
    public String whatICanDo()
    {
        String str = "";
        for(int i = 0 ; i < s.size() ; i++){
            str += s.get(i).whatICanDo() + "\n";
        }
        return str;
    }
    
    public double getMaximum()
    {
        return maxPrice;
    }
    
    public double getAverage()
    {
        return (sum / (double)s.size());
    }
    
    public Animal get(int i)
    {
        return s.get(i);
    }
}
/*
 * Represents a hamster
 * Jay Manchiraju
 * 1/16/2017
 */
public class Hamster extends Animal {
    String thingToSay;
    double price;
    public Hamster(double paraa, String parab) 
    {
        super(paraa,parab);
    }
    
    public String runWheel()
    {
        return "I run on a wheel";
    }
    
    public String whatICanDo()
    {
        return this.runWheel();
    }
}
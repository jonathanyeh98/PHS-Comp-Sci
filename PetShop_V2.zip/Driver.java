/**
 * Jonathan Yeh
 * Driver
 * 
 * <Description>
 */

public class Driver
{
    public static void main(String[] args)
    {
        PetSet ps = new PetSet();
        
        ps.add(new Hamster(15.00,"I am a Hampster"));
        ps.add(new Aligator(700.00,"I am an Aligator"));
        ps.add(new Turtle(50.00,"I am a Turtle"));
        
        System.out.println(ps.whatICanDo());
        System.out.println(ps);
    }
}
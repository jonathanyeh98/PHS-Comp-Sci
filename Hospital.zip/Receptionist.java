import java.lang.Math;
/**
 * Jonathan Yeh
 * Receptionist
 * 
 * Receptionists pick up a random number of phones calls from 0-9
 */

public class Receptionist extends AdminStaff
{
    private int phonecalls()
    {
        return (int)(Math.random()*10);
    }
    
    public Receptionist(String n)
    {
        super(n,"Receptionist");
    }
    
    public void callPeople()
    {
        System.out.println(this.toString() + " picked up and made " + this.phonecalls() + " phone calls.");
    }
}
/**
 * Jonathan Yeh
 * Hospital
 * 
 * represents a hospital and its employees.
 */

public class Hospital
{
    public static void main(String[] args)
    {
        System.out.println("The President");
        President p = new President("Barrack Obamacare");
        p.doPrezStuff();
        
        System.out.println("\nReceptionists");
        Receptionist r1 = new Receptionist ("Pam Beasly");
        Receptionist r2 = new Receptionist ("Celia Mae");
        r1.callPeople();
        r2.callPeople();
        
        System.out.println("\nDoctors");
        Doctor d1 = new Doctor("Gregory House");
        Doctor d2 = new Doctor("Emmett Brown");
        d1.prescribeMed("Painkillers");
        d2.diagnose("the Hiccups");
        
        System.out.println("\nNurses");
        Nurse n1 = new Nurse("Gaylord Focker");
        n1.assist(d2);
        n1.giveShot();
    }
}
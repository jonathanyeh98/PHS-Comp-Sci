/**
 * Jonathan Yeh
 * Doctor
 * 
 * Doctors prescribe medicine and diagnose patients 
 */

public class Doctor extends MedStaff
{
    public Doctor(String n)
    {
        super(n,"Doctor");
    }
    
    public void prescribeMed(String m)
    {
        System.out.println(this.toString() + " prescribes " + m + " to a patient.");
    }
    
    public void diagnose(String d)
    {
        System.out.println(this.toString() + " diagnosed a patient with " + d + ".");
    }
}
/**
 * Jonathan Yeh
 * President
 * 
 * The president of the hospital. can do president stuff
 */

public class President extends AdminStaff
{
    public President(String n)
    {
        super(n,"President");
    }
    
    public void doPrezStuff()
    {
        System.out.println(this.toString() + " did their presidential tasks.");
    }
}
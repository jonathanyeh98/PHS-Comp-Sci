/**
 * Jonathan Yeh
 * AdminStaff
 * 
 * Creates adminstration staff object. Has the administrate method
 */

public class AdminStaff extends Employee
{
    public AdminStaff(String n , String j)
    {
        super(n,j,"Administration");
    }
    public AdminStaff(String n)
    {
        super(n,"Administrator","Administration");
    }
    public void administrate()
    {
        System.out.println(this.toString() + " administrated stuff.");
    }
}
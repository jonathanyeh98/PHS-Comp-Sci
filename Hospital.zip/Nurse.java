/**
 * Jonathan Yeh
 * Nurse
 * 
 * Nurses assist doctors and give shots to patients
 */

public class Nurse extends MedStaff
{
    public Nurse(String n)
    {
        super(n,"Nurse");
    }
    
    public void assist(Doctor d)
    {
        System.out.println(this.toString() + " assisted " + d + ".");
    }
    
    public void giveShot()
    {
        System.out.println(this.toString() + " gave a patient a shot.");
    }
}
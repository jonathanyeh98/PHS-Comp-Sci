/**
 * Jonathan Yeh
 * Employee
 * 
 * Creates the employee object. Has a name, job title, branch
 */

public class Employee
{
    private String name;
    private String job;
    private String branch;
    
    public Employee(String n , String j , String b)
    {
        name = n;
        job = j;
        branch = b;
    }
    
    public String toString()
    {
        return job + " " + name + " (" + branch + ")";
    }
    
    public void doTask()
    {
        System.out.println(this.toString() + " did their tasks.");
    }
}
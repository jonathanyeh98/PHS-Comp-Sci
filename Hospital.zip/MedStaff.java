/**
 * Jonathan Yeh
 * MedStaff
 * 
 * Creates med staff object
 */

public class MedStaff extends Employee
{
    public MedStaff(String n , String j)
    {
        super(n,j,"Medical Team");
    }
}
/**
 * Jonathan Yeh
 * Soccer
 * 
 * represents soccer
 */

public class Soccer extends Sport
{
    private int t1Penalties = 0;
    private int t2Penalties = 0;
    
    public Soccer(String t1, String t2)
    {
        super("Soccer",t1,t2);
    }
    
    public void penalty(int tNum)
    {
        if(onGoingGame)
        {
            if(tNum == 1)
            {
                t1Penalties++;
            }
            else if(tNum == 2)
            {
                t2Penalties++;
            }
            System.out.println(this.getTeam(tNum) + " gets a penalty.");
        }
        else
        {
            System.out.println("Game has ended. Penalties cannot be called");
        }
    }
    
    public String getPenaltyCount()
    {
        return "Penalties: " + this.getTeam(1) + ": " + t1Penalties + " VS " + this.getTeam(2) + ": " + t2Penalties;
    }
}
/**
 * Jonathan Yeh
 * SportsDriver
 * 
 * <Description>
 */

public class SportsDriver
{
    public static void main(String[] args)
    {   
        System.out.println("Football Game Start:");
        Football f = new Football("Patriots" , "Losers");
        f.score(1,1,2);
        f.score(1,1,1);
        f.score(2,2,0);
        f.score(1,1,0);
        System.out.println(f.result());
        f.score(2,1,1); //Tests the onGoingGame
        System.out.println();
        
        System.out.println("Soccer Game Start:");
        Soccer s = new Soccer("Germany" , "Brazil");
        s.score(2);
        s.score(1);
        s.score(1);
        s.score(1);
        s.penalty(1);
        s.penalty(2);
        s.penalty(1);
        s.score(1);
        s.score(1);
        System.out.println(s.result());
        System.out.println(s.getPenaltyCount());
        System.out.println();
        
        System.out.println("Volleyball Game Start: ");
        Volleyball v = new Volleyball("Princeton High","Princeton Day");
        v.score(1);
        v.score(2);
        v.score(1);
        v.score(1);
        v.score(2);
        v.score(1);
        v.score(1);
    }
}
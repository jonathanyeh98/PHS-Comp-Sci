/**
 * Jonathan Yeh
 * Golf
 * 
 * There is a maximum for points. the max score will be 4 for simplicity sake
 */

public class Volleyball extends Sport
{
    private boolean winMessagePlayed = false;
    
    public Volleyball(String t1, String t2)
    {
        super("Volleyball",t1,t2);
    }
    
    public void score(int tNum)
    {
        super.score(tNum);
        if(((this.getScore(1) == 4) || (this.getScore(2) == 4)) && (!winMessagePlayed))
        {
            System.out.println(this.result());
            winMessagePlayed = true;
        }
    }
}
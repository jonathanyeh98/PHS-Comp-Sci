/**
 * Jonathan Yeh
 * Sport
 * 
 * Keeps track of current score of a sport between two teams
 */

public class Sport
{
    private String team1;
    private String team2;
    private String sportName;
    private int t1Score = 0;
    private int t2Score = 0;
    public boolean onGoingGame;
    
    public Sport(String s , String t1 , String t2)
    {
        sportName = s;
        team1 = t1;
        team2 = t2;
        onGoingGame = true;
    }
    
    public String currScore()
    {
        String s;
        s = team1 + ": " + t1Score + " VS " + team2 + ": " + t2Score; 
        if(!onGoingGame)
        {
            s = "The game has already ended with a score of " + s;
        }
        return s;
    }
    
    public String getTeam(int tNum)
    {
        String team;
        if(tNum == 1)
        {
            team = team1;
        }
        else
        {
            team = team2;
        }
        return team;
    }
    
    public int getScore(int tNum)
    {
        int scores = 0;
        if(tNum == 1)
        {
            scores = t1Score;
        }
        else if(tNum == 2)
        {
            scores = t2Score;
        }
        return scores;
    }
    
    public void addPoints(int tNum, int points)
    {
        if(tNum == 1)
        {
            t1Score += points;
        }
        else
        {
            t2Score += points;
        }
    }
    
    public void score(int tNum)
    {
        if(onGoingGame)
        {
            String team = this.getTeam(tNum);
            this.addPoints(tNum , 1);
            System.out.println(team + " Scores\nCurrent Score: " + this.currScore());
        }
        else
        {
            System.out.println("Game has ended. Score does not count.");
        }
    }
    
    public String result()
    {
        String s = "Game over\nFinal Score: " + this.currScore() + "\n";
        onGoingGame = false;
        if(t1Score > t2Score)
        {
            s += team1 + " wins!";
        }
        else if(t2Score > t1Score)
        {
            s = team2 + " wins!";
        }
        else if(t1Score == t2Score)
        {
            s = "Tie";
        }
        return s;
    }
}
/**
 * Jonathan Yeh
 * Football
 * 
 * Represents football. The Scores are set: touchdown = 6, 
 * field goal = 3, second point touchdown = 2, second point kick 1
 * field goal cannot have second point
 */

public class Football extends Sport
{
    public Football(String t1, String t2)
    {
        super("Football",t1,t2);
    }
    
    public void touchdown(int tNum , int scoretype2)
    {
        this.addPoints(tNum, 6);
        System.out.println(this.getTeam(tNum) + " Touchdown!\nCurrent Score: " + this.currScore());        
        if(scoretype2 == 1)
        {
            this.addPoints(tNum, scoretype2);
            System.out.println("Second point kick success\nCurrent Score: " + this.currScore());
        }
        else if(scoretype2 == 2)
        {
            this.addPoints(tNum, scoretype2);
            System.out.println("Second point touchdown success\nCurrent Score: " + this.currScore());
        }
        else if(scoretype2 == 0)
        {
            System.out.println("Second point failed");
        }
    }
    
    public void fieldGoal(int tNum)
    {
        this.addPoints(tNum, 3);
            System.out.println(this.getTeam(tNum) + " Field Goal!\nCurrent Score: " + this.currScore());
    }
    
    public void score(int tNum , int scoretype, int scoretype2)
    {
        if(onGoingGame)
        {
            //Touchdown is 1 , field goal is 2
            if(scoretype == 1)
            {
                this.touchdown(tNum , scoretype2);
            }
            else if(scoretype == 2)
            {
                this.fieldGoal(tNum);
            }
        }
        else
        {
            System.out.println("Game has ended. Score does not count.");
        }
    }
}
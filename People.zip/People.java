
/**
 * Jonathan Yeh
 * People
 * 
 * The basic person with the basic information
 */
public class People
{
    private String name;
    private int age;
    private boolean isMale;
    
    public People(String n , int a, int i)
    {
        name = n;
        age = a;
        if(i == 1)
        {
            isMale = true;
        }
        else if(i==2)
        {
            isMale = false;
        }
    }
    
    public String getName()
    {
        return name;
    }
    
    public int getAge()
    {
        return age;
    }
    
    public void setName(String n)
    {
        name = n;
    }
    
    public void setAge(int a)
    {
        age = a;
    }
    
    public String getGender()
    {
        String s;
        if(isMale)
        {
            s = "M";
        }
        else
        {
            s = "F";
        }
        return s;
    }
    
    public String toString()
    {
        return "Name: " + name + " | Gender: " + this.getGender() + " | Age: " + age;
    }
}
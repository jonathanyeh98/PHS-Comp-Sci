
/**
 * Jonathan Yeh
 * Nationality
 * 
 * Personal information including race and nationality
 */
public class Nationality extends People
{
    String race;
    String nationality;
    
    public Nationality(String n, int a, int i , String r , String nat)
    {
        super(n,a,i);
        nationality = nat;
        race = r;
    }
    
    public String getNationality()
    {
        return nationality;
    }
    
    public String getRace()
    {
        return race;
    }
    
    public String toString()
    {
        return super.toString() + " | Race: " + race + " | Nationality: " + nationality;
    }
}

/**
 * Jonathan Yeh
 * Occupation
 * 
 * Personal information including occupation and income
 */
public class Occupation extends People
{
    private String job;
    private double income;
    
    public Occupation(String n, int a , int i , String j, double in)
    {
        super(n,a,i);
        job = j;
        income = in;
    }
    
    public String getJob()
    {
        return job;
    }
    
    public double getIncome()
    {
        return income;
    }
    
    public String toString()
    {
        return super.toString() + " | Occupation: " + job + " | Income: " + income;
    }
}
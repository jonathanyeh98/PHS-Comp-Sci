/**
 * Jonathan Yeh
 * CommunityDriver
 * 
 * Driver to test People, its child classes, and Community
 */

public class CommunityDriver
{
    public static void main(String[] args)
    {
        Community c = new Community();
        c.add(new People("Sally Sue",6,2));
        c.add(new Nationality("Johnny Sue",12,1,"American","Caucasian"));
        c.add(new Nationality("Michelle Bobama",50,2,"American","Black"));
        c.add(new Occupation("Brock Bobama",52,1,"President",500000.00));
        c.add(new Occupation("Joe Jacksong",36,1,"Shop Owner",70000.00));
        
        System.out.println(c);
        System.out.println(c.getDetails());
    }
}
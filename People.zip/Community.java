import java.util.ArrayList;
/**
 * Jonathan Yeh
 * Community
 * 
 * A set of people
 */
public class Community
{
    private ArrayList<People> community;
    
    public Community()
    {
        community = new ArrayList<People>();
    }
    
    public void add(People p)
    {
        community.add(p);
    }
    
    public String toString()
    {
        String s = "";
        for(int i = 0 ; i < community.size() ; i++)
        {
            s += community.get(i).getName() + "(" + community.get(i).getAge() + " " + community.get(i).getGender() + ")\n";
        }
        return s;
    }
    
    public String getDetails()
    {
        String s = "";
        for(int i = 0 ; i < community.size() ; i++)
        {
            s += community.get(i).toString() + "\n";
        }
        return s;
    }
}